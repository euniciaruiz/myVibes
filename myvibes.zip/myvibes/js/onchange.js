$(document).ready(function() {

    //if submit button is clicked
    $('form#friendreq').submit(function(){  

		$('#upload_wrapper').hide();


		$('#image_wrapper').show();
		}

		);
});