
<div class="recommendation-title">
	<strong>What's Hot With My Friends</strong>
</div><hr>
<div class="list-reco font3">
<?php echo $row8; ?>
</div>