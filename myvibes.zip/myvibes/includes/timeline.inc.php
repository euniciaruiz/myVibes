	<!--<div class="timeline-title">
		<strong>Music Feed</strong>
	</div>
	<hr>-->
	<div class="list-timeline">
<ul class="statuses"><?php echo $timeline; ?></ul>
<div class="pagination pagination-centered">
	<?php  echo $pages->display_pages(); ?>
</div>
	</div>