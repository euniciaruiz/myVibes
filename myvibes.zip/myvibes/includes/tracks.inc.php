
	<ul class="statuses"><?php echo $timeline?></ul>
	<div class="pagination pagination-centered">
	<!--?php echo $page2 ?>-->
	</div>
	<!--<div class="pagination pagination-centered">
	?php echo $page1 ?>
	</div>-->
