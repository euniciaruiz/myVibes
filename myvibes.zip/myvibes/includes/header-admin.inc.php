
<div class="navbar navbar-inverse navbar-fixed-top"> 
  <div class="navbar-inner"> 
    <div class="container"><a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
      <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> 
      </a> <a class="brand" href="admin.php"><img src="img/2213.png" width= "100px"/></a>
      <div class="nav-collapse collapse"> 
        <ul class="nav">
          <li class="active"><a href="admin.php"><i class="icon-home" style='margin-right:5px'></i>Home</a></li>
        </ul>
		<ul class="nav pull-right">
			<li><a href="logout.php"><i class="icon-off" style='margin-right:5px'></i>Logout</a></li></div>
		</ul>
      </div>
      <!--/.nav-collapse -->
    </div>
  </div>
</div>
</div>