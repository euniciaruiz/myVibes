
<div class="navbar navbar-inverse navbar-fixed-top"> 
  <div class="navbar-inner"> 
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
      <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> 
      </a> <a class="brand" href="login.php"><img src="img/2213.png" width= "100px"/></a>
      <div class="nav-collapse collapse"> 
        <ul class="nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li class="active"><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
  </div>
</div>