<div class="list-reco font1">
	<div class="span3" style='margin-bottom:20px'>
		<div class="font3">
		<strong>PageRank-based Recommendation</strong>
		<br/><br/>
		<div id="example-1"></div>		
			Your Rating: <span id="example-rating-1">not set</span>
		</div>
		<hr>
		<?php echo $row7;?><br/><br/>
	</div>
	
		<div class="span3" style='margin-bottom:20px'>
		<div class="font3">
		<strong>Play Count-based Recommendation</strong>
		<br/><br/>
		<div id="example-2"></div>
		
			Your Rating: <span id="example-rating-2">not set</span>
		</div>
		<hr>
		<?php echo $row11;?>
	</div>
</div>
