<div class="navbar navbar-inverse navbar-fixed-bottom"'>
	<div class="navbar-inner" style='min-height:25px;'>
		<div class="container-fluid">
			<div class="font2">
			&copy; Copyright 2013 MyVibes
			
			<a href="about-index.php" style="text-decoration:none;color:#999;margin-left:75%">About</a>
			<a href="contact-index.php" style="text-decoration:none;color:#999;margin-left:1%">Contact</a>
	
		</div>
		</div>
	</div>
</div>