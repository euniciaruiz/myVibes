<hr>
<div class="footer footerPattern">
		<p class="font1">&copy; 2012-2020 Fuentes. Bacarrisas. Olaer</p>
	</div>