
<div class="recommendation-title">
	<strong>In With The MyVibes Community</strong>
</div><hr>
<div class="list-reco font3">
<?php echo $row9; ?>

</div>