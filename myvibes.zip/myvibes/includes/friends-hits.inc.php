
<div class="list-reco font1">
	<div class="span3" style='margin-bottom:20px'>

		<div class="font3">
		<strong>PageRank-based Recommendation</strong>
		<br/><br/>
		<div id="example-3"></div>
			Your Rating: <span id="example-rating-3">not set</span>
		</div>
		<hr>
		<?php echo $row8; ?>

	</div>
	
		<div class="span3" style='margin-bottom:20px'>
		<div class="font3">
		<strong>Play Count-based Recommendation</strong>
		<br/><br/>
		<div id="example-4"></div>
			Your Rating: <span id="example-rating-4">not set</span>
		</div>
		<hr>
		<?php echo $row32; ?>
	</div>
</div>