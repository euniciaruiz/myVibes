//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by music_reporter.rc
//
#define IDD_MAIN                        101
#define IDD_CONF                        102
#define IDD_About                       103
#define IDB_DP                          110
#define IDB_CAT                         111
#define IDC_ENABLE                      1001
#define IDC_EDIT_USER                   1003
#define IDC_EDIT_HASH                   1004
#define IDC_EDIT_DISPLAY_FORMAT         1008
#define IDC_STATUS                      1013
#define IDC_CUSTOM1                     1014
#define IDC_TAB                         1021
#define IDC_PIC_CAT                     1022
#define IDC_PETER_EMAIL                 1023
#define IDC_PETER_URL                   1024
#define IDC_ABUZANT_URL                 1025
#define IDC_PETER                       1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
