/*
** Peteris Krumins (peter@catonmat.net)
** http://www.catonmat.net  --  good coders code, great reuse
**
** A Winamp plugin for reporting what music you are listening to
** Digital Point Forums. It was written in 2006.
**
** Latest version and explanation of how it was written is always at:
** http://www.catonmat.net/projects/dpf-winamp-music-reporter
*/

#ifndef DPF_DIALOG_ABOUT_H
#define DPF_DIALOG_ABOUT_H

#include <windows.h>

INT_PTR CALLBACK TabAboutProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif

