//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDD_DIALOG1                     101
#define IDC_CHECK1                      1000
#define IDC_ENABLE                      1000
#define IDC_EDIT1                       1001
#define IDC_PORTS                       1001
#define IDC_MAXCON                      1002
#define IDC_MAXRES                      1003
#define IDC_ALLOW_1                     1004
#define IDC_USER_1                      1005
#define IDC_PASS_1                      1006
#define IDC_CONTROL_1                   1007
#define IDC_STREAM_1                    1008
#define IDC_ALLOW_2                     1009
#define IDC_USER_2                      1010
#define IDC_PASS_2                      1011
#define IDC_CONTROL_2                   1012
#define IDC_STREAM_2                    1013
#define IDC_ALLOW_3                     1014
#define IDC_USER_3                      1015
#define IDC_PASS_3                      1016
#define IDC_CONTROL_3                   1017
#define IDC_STREAM_3                    1018
#define IDC_ALLOW_4                     1019
#define IDC_USER_4                      1020
#define IDC_PASS_4                      1021
#define IDC_CONTROL_4                   1022
#define IDC_STREAM_4                    1023
#define IDC_AUTHCHECK                   1024
#define IDC_REFRESH                     1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
