To compile ml_www, you'll need the Winamp 5 SDK:

And JNetLib v0.4 or higher:

http://www.nullsoft.com/free/jnetlib/ for the most current version

Note: Justin deserves all credits for this code, I just barely packaged it :)

-Christophe/Nullsoft 2004