//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ex.rc
//
#define IDD_DIALOG1                     101
#define IDR_CONTEXTMENUS                102
#define IDD_SEND_FILES                  103
#define IDD_CONFIG                      104
#define IDD_EDIT_INFO                   105
#define IDD_VIEW_IPOD                   221
#define IDD_VIEW_NJB                    221
#define IDD_VIEW_EX                     221
#define IDD_INIT                        222
#define IDC_PROGRESS1                   1000
#define IDC_STATUS                      1001
#define IDC_EDIT_ARTIST                 1002
#define IDC_PROGRESS2                   1002
#define IDC_CHECK_ARTIST                1003
#define IDC_CHECK_TITLE                 1004
#define IDC_CHECK_ALBUM                 1005
#define IDC_QUICKSEARCH                 1006
#define IDC_CHECK_TRACK                 1006
#define IDC_CHECK_GENRE                 1007
#define IDC_CHECK_YEAR                  1008
#define IDC_EDIT_TITLE                  1009
#define IDC_EDIT_ALBUM                  1010
#define IDC_BUTTON_AUTODETECT           1010
#define IDC_EDIT_TRACK                  1011
#define IDC_CHECK1                      1011
#define IDC_EDIT_GENRE                  1012
#define IDC_DETECTDUPS                  1012
#define IDC_EDIT_YEAR                   1013
#define IDC_CURTRACKNAME                1013
#define IDC_BUTTON_PLAY                 1016
#define IDC_BUTTON_ENQUEUE              1017
#define IDC_BUTTON_REFRESH              1018
#define IDC_BUTTON_CONFIG               1018
#define IDC_IPODSTATUS                  1030
#define IDC_LIST                        1031
#define IDC_COMBO1                      1032
#define IDC_COMBO2                      1033
#define IDC_TEXT_GENRE                  1039
#define IDC_TEXT_BITRATE                1040
#define ID_IPODWND_REMOVEFROMIPOD       40001
#define ID_IPODTREEITEMCONTEXT_ABOUTIPOD 40002
#define ID_ABOUT                        40002
#define ID_IPODTREEITEMCONTEXT_IPODCONFIGURATION 40003
#define ID_CONFIG                       40003
#define ID_IPODWND_EDITITEMSINFORMATIONS 40004
#define ID_IPODWND_PLAYSELECTEDFILES    40013
#define ID_IPODWND_ENQUEUESELECTEDFILES 40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
