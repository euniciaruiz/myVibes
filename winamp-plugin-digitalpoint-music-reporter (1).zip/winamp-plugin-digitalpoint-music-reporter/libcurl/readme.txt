This is the ./libcurl directory in DPF Winamp Plugin's source tree. If you
want to compile the plugin yourself, you should download LibCurl and extract
it here. Please follow the instructions in compile.txt to do it. It's really
simple.

